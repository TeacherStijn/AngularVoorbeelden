import {Component, OnChanges, OnInit} from '@angular/core';
import {Bordspel} from '../shared/models/bordspel';
import {BordspelService} from '../shared/services/bordspel.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnChanges {
  title = 'CRUD';
  imageLocation: string = '../assets/images/';
  // favourite: string;
  spellen: Bordspel[];

  constructor(private bordspellenService: BordspelService) {
    /*this.bordspellenService.$spellen.subscribe(
      (data) => this.spellen = data.map(
        (el) => {
          return {
            titel: el.name,
            maker: 'unknown',
            jaartal: el.yearPublished,
            rating: el.averageRating
          };
        }
      )
    );*/
  }

  ngOnInit(): void {
    // this.favourite = 'Settlers of Catan';
    this.spellen = [
      new Bordspel('Terraforming Mars', 'x', 2016, 8, 'terraformingmars.jpeg'),
      new Bordspel('Charterstone', 'y', 2017, 9, 'charterstone.jpeg'),
      new Bordspel('Gloomhaven', 'z', 2018, 10, 'gloomhaven.jpg')
    ];
  }

  add(ev: Event, form) {
    ev.preventDefault();

    console.log(form.txtTitel.value);

    this.spellen.push(
      new Bordspel(form[0].value, form[1].value, form[2].value, form[3].value)
    );

    form.reset();
  }

  ngOnChanges(change) {
    console.log('iets veranderd!');
    console.dir(change);
  }

  remove(titel: string) {
    const gevonden = this.spellen.findIndex(e => {
      return e.titel === titel;
    });

    this.spellen.splice(gevonden, 1);
  }

  invoer() {
    console.log('Er is iets in het invoerveld ingevoerd');
  }
}
