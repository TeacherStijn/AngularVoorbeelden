import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BordspelService {

  $spellen: Observable<any>;

  constructor(private http: HttpClient) {
    this.$spellen = this.http.get('\thttps://bgg-json.azurewebsites.net/collection/edwalter');
  }
}
