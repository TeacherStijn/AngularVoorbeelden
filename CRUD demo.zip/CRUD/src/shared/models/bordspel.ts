export class Bordspel {
  constructor(
              // evt id erbij voor easy search
              public titel: string
            , public maker: string
            , public jaartal: number
            , public rating?: number
            , public imageUrl?: string
  ) {
  }

  toString(): string {
    return `Prachtig spel genaamd ${this.titel} gemaakt in ${this.jaartal} door ${this.maker} met een rating van: ${this.rating}`;
  }
}
